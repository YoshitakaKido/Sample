int i, j, k;
int a[100];


void zzz(int b[100], int l)
{
	b[1+i] = 0;
	a[1+i] = 0;
	b[0] = 0;
	a[0] = 0;
	zzz(&b[1], l);
	zzz(&b[2], &i);
	zzz(b, &l);
}

void main()
{
	zzz(&i, j);
	zzz(&j, &k);
}

