//=============================================//
//   Mips Object Code Interface       "Mips.h" //
//=============================================//
//                              Tan Watanabe, UEC
#pragma SC once
#ifndef MIPS
#define MIPS
#include "sub.h"
#include "arm.h"

//========== MachineReg Class ==========//
                          //---- Mips machine register inf
enum Mrg_usage {
  mrgUse,            // Use the value of a register
  mrgSet             // Set a   value to a register
};
class MachineReg {
public:
  Reg_symP armReg;   // Bounded Rcode register (NULL if none)
  Reg_symP mrgChain; // Allocation chain
  int      mrgNumb;  // Register number
  //----- Member functions --------//
           MachineReg(void) { armReg = NULL; mrgChain = NULL; }
  Reg_symP ArmReg    (void) { return armReg; }
  int      MrgNumb   (void) { return mrgNumb; }
  void     ArmRegSet (Reg_symP p) { armReg = p; }  
  Reg_symP MrgInit (  // Initiate a machine register.
                    String pRegName,  // Register name 
                    int pRegNumb);    // Register number
  Reg_symP MrgSearch( // Search machine reg to be allocated.
                     Reg_symP pArmReg, // Rcode register
                     int      pLevel); // 1: Search unused reg, 
                                       // 2: search noHolg reg.
  void     Print     ();  // Print machine register information.
  void     Initiation();  // Initiate machine registers.
}; //---- MachineReg class end ----//

//-------- Global symbols -------//
typedef  MachineReg* MachineRegP;  
Reg_symP MipsReg( // Allocate Mips register to Rcode register.
                 Reg_symP  pArmReg, // Rcode reg for allocation.
                 Mrg_usage pUsage); // Use mode or set mode.
void MipsCode(   // Generate Mips code corresponding to Rcode.
              Ac_form pForm, Sym_opCodeT pOpCode, Reg_symP pReg1,
              Reg_symP pReg2, Reg_symP pReg3, SymbolP pSym,
              int pInt);
extern MachineReg mrg_reg;  // Machine register instance.
extern Reg_symP 
  mrg_mips[32],  // Mips machine register pointers.
  mrg_zero, mrg_rval, mrg_param, mrg_temp, mrg_saved, 
  mrg_stackp, mrg_raddr;
#define MRG_searchLim 10

#endif
  
