int _a_[100];
int b;

void zzz(int c[100], int d)
{
	c[0] = 0;
	c[1] =
}

void main()
{
	b = _a_[1];
	b = &_a_[2];
	b = &b;
}
